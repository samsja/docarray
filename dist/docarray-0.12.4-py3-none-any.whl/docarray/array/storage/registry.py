from collections import defaultdict

_REGISTRY = defaultdict(lambda: defaultdict(list))
